<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'basicdynamic' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'MD:~7.]t:sE}^YID14`TDY`E7Mu-@a1;g>:-3#&ogo+Un9e?;;w|m1n+{(=/1p>h' );
define( 'SECURE_AUTH_KEY',  'g.V%R?ydYb!jFWoLi.+BVD1exT(bv,E}G;EOUFU4zm^27|53N5]2Rn]5@09g(;NZ' );
define( 'LOGGED_IN_KEY',    'jq-D7qWaY6xoMIgN<. ._]^@?.DG}R[<ffQ:>Y<v~>d!;gv5aQ^-o35$f=1VQZ~0' );
define( 'NONCE_KEY',        '8$TGp{=r%a9z0cA&wIY9a+29jfJsY4L(s>)5%G1wm%<fLdm/z0z>>jcT}KWi=||4' );
define( 'AUTH_SALT',        'yw[>aV^DDM;9WDzC4Qq!9NCY4c;:Badmf]UeF?+XPp3#yz|o*JG&dH1P~E-|t%bl' );
define( 'SECURE_AUTH_SALT', 'Q!bp%0$CzK eubRQ%7:))2gtrnCRWWZ1OMnbE<Y__GZ3bX3y-G41xrT4XjC(^K=Y' );
define( 'LOGGED_IN_SALT',   '7Yn,t5^t#7q:smoWj^*r{cv]=`*G2^:vuaJk)?rNy|s_&MTCq4*(+_~jDhLtp x+' );
define( 'NONCE_SALT',       'b0QgHwYZ];MH>aT?w&I<+EQg1FE(uM 4u%XDon`qqz*:mV.;<s$.l01:QNh:ra~j' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', true );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
